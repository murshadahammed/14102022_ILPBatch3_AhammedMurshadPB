package com.experion.service;

import com.experion.entity.Account;

public interface LoanService {

		public Account chequeDeposit(Account account);
}
