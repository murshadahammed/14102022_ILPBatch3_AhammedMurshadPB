package com.experion.service;

public interface CurrentService {
	public void mobileBanking();
}
