package com.bank.entity;

public class Service {

	private String serviceName;

	public Service(String serviceName) {
		super();
		this.serviceName = serviceName;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
}
